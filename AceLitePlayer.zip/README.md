# AceLite Player & Video Downloader

A lightweight, native Android Video Player & Downloader built with Kotlin, Jetpack Compose, Media3 (ExoPlayer), and WorkManager.

## How to Build the APK Using Only Your Phone (GitHub Actions)

1. **Extract this ZIP file** on your Android phone (using your built-in Files app or ZArchiver).
2. Open your mobile browser, go to [GitHub](https://github.com), and create a **New Repository** (e.g., `AceLitePlayer`).
3. Tap **uploading an existing file**, select all extracted files/folders (including the hidden `.github` folder!), and commit them to the `main` branch.
   * *Tip:* If your phone's file picker hides `.github`, create a new file on GitHub directly named `.github/workflows/build.yml` and paste the contents of `build.yml` into it.
4. Go to the **Actions** tab in your GitHub repository.
5. Wait ~3–5 minutes for the **Build Android APK** workflow to finish with a green checkmark.
6. Open the completed workflow run, scroll down to **Artifacts**, and tap **AceLite-Player-Debug-APK** to download and install the APK on your phone!
