package com.example.aceliteplayer

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PictureInPictureParams
import android.content.ContentUris
import android.content.Context
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Rational
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale

data class VideoQualityOption(
    val label: String,
    val url: String,
    val sizeText: String,
    val durationText: String
)

object StreamInspector {
    private val client = OkHttpClient()

    suspend fun inspectStream(url: String): List<VideoQualityOption> = withContext(Dispatchers.IO) {
        if (url.lowercase().contains(".m3u8")) {
            inspectHlsPlaylist(url)
        } else {
            inspectDirectFile(url)
        }
    }

    private fun inspectHlsPlaylist(m3u8Url: String): List<VideoQualityOption> {
        val options = mutableListOf<VideoQualityOption>()
        try {
            val baseUrl = m3u8Url.substringBeforeLast("/") + "/"
            val body = client.newCall(Request.Builder().url(m3u8Url).build()).execute().body?.string()
                ?: return emptyList()
            val lines = body.lines().map { it.trim() }

            if (body.contains("#EXT-X-STREAM-INF")) {
                var durationSeconds = 0.0
                for (i in lines.indices) {
                    val line = lines[i]
                    if (line.startsWith("#EXT-X-STREAM-INF")) {
                        val nextUrl = lines.getOrNull(i + 1)?.let {
                            if (it.startsWith("http")) it else baseUrl + it
                        } ?: continue

                        val resMatch = Regex("RESOLUTION=\\d+x(\\d+)").find(line)
                        val height = resMatch?.groupValues?.get(1)
                        val label = if (height != null) "${height}p" else "Stream Option ${options.size + 1}"

                        val bwMatch = Regex("BANDWIDTH=(\\d+)").find(line)
                        val bandwidth = bwMatch?.groupValues?.get(1)?.toLongOrNull() ?: 0L

                        if (durationSeconds == 0.0) {
                            durationSeconds = fetchHlsDuration(nextUrl)
                        }

                        val estimatedBytes = if (bandwidth > 0 && durationSeconds > 0) {
                            ((bandwidth * durationSeconds) / 8.0).toLong()
                        } else 0L

                        options.add(
                            VideoQualityOption(
                                label = label,
                                url = nextUrl,
                                sizeText = if (estimatedBytes > 0) "~${formatBytes(estimatedBytes)}" else "Unknown size",
                                durationText = formatDuration((durationSeconds * 1000).toLong())
                            )
                        )
                    }
                }
            } else {
                val durationSec = parseDurationFromMediaPlaylist(lines)
                options.add(
                    VideoQualityOption(
                        label = "Standard Stream",
                        url = m3u8Url,
                        sizeText = "Variable size",
                        durationText = formatDuration((durationSec * 1000).toLong())
                    )
                )
            }
        } catch (_: Exception) { }
        return options.distinctBy { it.label }
    }

    private fun fetchHlsDuration(subPlaylistUrl: String): Double {
        return try {
            val text = client.newCall(Request.Builder().url(subPlaylistUrl).build()).execute().body?.string() ?: return 0.0
            parseDurationFromMediaPlaylist(text.lines())
        } catch (_: Exception) { 0.0 }
    }

    private fun parseDurationFromMediaPlaylist(lines: List<String>): Double {
        var total = 0.0
        for (line in lines) {
            if (line.startsWith("#EXTINF:")) {
                val secStr = line.removePrefix("#EXTINF:").substringBefore(",")
                total += secStr.toDoubleOrNull() ?: 0.0
            }
        }
        return total
    }

    private fun inspectDirectFile(url: String): List<VideoQualityOption> {
        var sizeBytes = -1L
        var durationMs = 0L
        var resolutionLabel = "Original Quality"

        try {
            val headReq = Request.Builder().url(url).head().build()
            client.newCall(headReq).execute().use { resp ->
                sizeBytes = resp.header("Content-Length")?.toLongOrNull() ?: -1L
            }
        } catch (_: Exception) { }

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(url, HashMap())
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            if (!height.isNullOrEmpty()) resolutionLabel = "${height}p"
        } catch (_: Exception) {
        } finally {
            retriever.release()
        }

        return listOf(
            VideoQualityOption(
                label = resolutionLabel,
                url = url,
                sizeText = if (sizeBytes > 0) formatBytes(sizeBytes) else "Unknown size",
                durationText = if (durationMs > 0) formatDuration(durationMs) else "--:--"
            )
        )
    }

    fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return String.format(Locale.US, "%.1f MB", mb)
    }

    fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000
        val hours = totalSec / 3600
        val mins = (totalSec % 3600) / 60
        val secs = totalSec % 60
        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, mins, secs)
        } else {
            String.format(Locale.US, "%02d:%02d", mins, secs)
        }
    }
}

object AudioExtractor {
    fun extractAudioToM4a(sourceVideo: File, outputAudio: File): Boolean {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        return try {
            extractor.setDataSource(sourceVideo.absolutePath)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (audioTrackIndex == -1 || audioFormat == null) return false

            extractor.selectTrack(audioTrackIndex)
            muxer = MediaMuxer(outputAudio.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val writeTrackIndex = muxer.addTrack(audioFormat)
            muxer.start()

            val buffer = ByteBuffer.allocate(256 * 1024)
            val bufferInfo = MediaCodec.BufferInfo()

            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(writeTrackIndex, buffer, bufferInfo)
                extractor.advance()
            }
            true
        } catch (_: Exception) {
            false
        } finally {
            try { muxer?.stop(); muxer?.release() } catch (_: Exception) {}
            extractor.release()
        }
    }
}

object AppSettings {
    private const val PREFS_NAME = "video_app_prefs"
    private const val KEY_NOTIFICATIONS_ENABLED = "download_notifications_enabled"

    fun areNotificationsEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_NOTIFICATIONS_ENABLED, true)
    }

    fun setNotificationsEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled).apply()
    }
}

object VaultManager {
    fun getLocalVideos(context: Context): List<Uri> {
        val videoList = mutableListOf<Uri>()
        val projection = arrayOf(MediaStore.Video.Media._ID)
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            while (cursor.moveToNext()) {
                videoList.add(ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cursor.getLong(idCol)))
            }
        }
        return videoList
    }

    fun moveDownloadedFileToVault(context: Context, file: File): Boolean {
        val vaultDir = File(context.filesDir, "private_vault").apply { if (!exists()) mkdirs() }
        val dest = File(vaultDir, file.name)
        return if (file.renameTo(dest)) true else try {
            file.copyTo(dest, overwrite = true); file.delete()
        } catch (_: Exception) { false }
    }

    fun restoreFromVault(context: Context, vaultFile: File): Boolean {
        val publicDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return false
        return vaultFile.renameTo(File(publicDir, vaultFile.name))
    }

    fun deleteFile(file: File): Boolean = try { file.exists() && file.delete() } catch (_: Exception) { false }

    fun authenticateUser(activity: FragmentActivity, onSuccess: () -> Unit) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Private Folder")
            .setSubtitle("Verify your identity to view hidden videos")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }
}

class VideoDownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val client = OkHttpClient()
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val channelId = "video_downloads_channel"
    private val notificationId = id.hashCode()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val videoUrl = inputData.getString("VIDEO_URL") ?: return@withContext Result.failure()
        val fileName = inputData.getString("FILE_NAME") ?: "video_${System.currentTimeMillis()}.mp4"
        val showNotifications = AppSettings.areNotificationsEnabled(applicationContext)

        if (showNotifications) {
            createNotificationChannel()
            setForeground(createForegroundInfo(fileName, 0))
        }

        val outputFile = File(applicationContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES), fileName)

        val success = if (videoUrl.lowercase().contains(".m3u8")) {
            downloadHlsSegments(videoUrl, outputFile) { progress ->
                updateProgress(fileName, progress, showNotifications)
            }
        } else {
            downloadDirectFile(videoUrl, outputFile) { progress ->
                updateProgress(fileName, progress, showNotifications)
            }
        }

        if (success) Result.success(workDataOf("FILE_PATH" to outputFile.absolutePath)) else Result.retry()
    }

    private suspend fun updateProgress(fileName: String, progress: Int, showNotifications: Boolean) {
        setProgress(workDataOf("PROGRESS" to progress, "FILE_NAME" to fileName))
        if (showNotifications) {
            notificationManager.notify(notificationId, buildNotification(fileName, progress))
        }
    }

    private suspend fun downloadDirectFile(url: String, outputFile: File, onProgress: suspend (Int) -> Unit): Boolean {
        return try {
            val response = client.newCall(Request.Builder().url(url).build()).execute()
            if (!response.isSuccessful) return false
            val body = response.body ?: return false
            val totalBytes = body.contentLength()

            body.byteStream().use { input ->
                FileOutputStream(outputFile).use { output ->
                    val buffer = ByteArray(8 * 1024)
                    var copied = 0L
                    var lastPct = -1
                    var bytes = input.read(buffer)
                    while (bytes >= 0) {
                        if (isStopped) return false
                        output.write(buffer, 0, bytes)
                        copied += bytes
                        if (totalBytes > 0) {
                            val pct = ((copied * 100) / totalBytes).toInt()
                            if (pct != lastPct && pct % 2 == 0) {
                                lastPct = pct
                                onProgress(pct)
                            }
                        }
                        bytes = input.read(buffer)
                    }
                }
            }
            true
        } catch (_: Exception) { false }
    }

    private suspend fun downloadHlsSegments(m3u8Url: String, outputFile: File, onProgress: suspend (Int) -> Unit): Boolean {
        return try {
            val baseUrl = m3u8Url.substringBeforeLast("/") + "/"
            val playlistText = client.newCall(Request.Builder().url(m3u8Url).build()).execute().body?.string() ?: return false
            val segments = playlistText.lines().map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .map { if (it.startsWith("http")) it else baseUrl + it }

            if (segments.isEmpty()) return false
            var lastPct = -1

            FileOutputStream(outputFile).use { output ->
                segments.forEachIndexed { index, segUrl ->
                    if (isStopped) return false
                    client.newCall(Request.Builder().url(segUrl).build()).execute().body?.byteStream()?.use { input ->
                        input.copyTo(output)
                    }
                    val pct = (((index + 1) * 100) / segments.size)
                    if (pct != lastPct && pct % 2 == 0) {
                        lastPct = pct
                        onProgress(pct)
                    }
                }
            }
            true
        } catch (_: Exception) { false }
    }

    private fun createForegroundInfo(fileName: String, progress: Int): ForegroundInfo {
        val notification = buildNotification(fileName, progress)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(notificationId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else ForegroundInfo(notificationId, notification)
    }

    private fun buildNotification(fileName: String, progress: Int): Notification {
        return NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("Downloading Video")
            .setContentText("$fileName ($progress%)")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                NotificationChannel(channelId, "Video Downloads", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
}

fun startVideoDownload(context: Context, url: String, fileName: String) {
    val req = OneTimeWorkRequestBuilder<VideoDownloadWorker>()
        .setInputData(workDataOf("VIDEO_URL" to url, "FILE_NAME" to fileName))
        .addTag("VIDEO_DOWNLOAD")
        .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
        .build()
    WorkManager.getInstance(context).enqueue(req)
}

@Composable
fun VideoThumbnail(videoUri: Uri, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(videoUri) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(videoUri) {
        withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, videoUri)
                val frame = retriever.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                bitmap = frame?.let { Bitmap.createScaledBitmap(it, 160, 90, true) }
            } catch (_: Exception) {
                bitmap = null
            } finally {
                retriever.release()
            }
        }
    }

    Box(
        modifier = modifier.size(96.dp, 54.dp).clip(RoundedCornerShape(8.dp)).background(Color.DarkGray),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
        }
    }
}

@Composable
fun GestureVideoPlayer(videoUri: Uri, activity: ComponentActivity) {
    val context = LocalContext.current
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }

    var brightness by remember { mutableFloatStateOf(0.5f) }
    var volumeLevel by remember { mutableIntStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)) }
    var activeGestureText by remember { mutableStateOf<String?>(null) }

    val speeds = listOf(1.0f, 1.25f, 1.5f, 2.0f)
    var speedIndex by remember { mutableIntStateOf(0) }
    val timerOptions = listOf(0, 15, 30, 60)
    var timerIndex by remember { mutableIntStateOf(0) }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(videoUri))
            prepare()
            playWhenReady = true
        }
    }

    LaunchedEffect(timerIndex) {
        val mins = timerOptions[timerIndex]
        if (mins > 0) {
            delay(mins * 60 * 1000L)
            exoPlayer.pause()
            timerIndex = 0
            Toast.makeText(context, "Sleep timer finished: Video paused", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(Unit) { onDispose { exoPlayer.release() } }

    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
            detectVerticalDragGestures(
                onDragEnd = { activeGestureText = null },
                onVerticalDrag = { change, dragAmount ->
                    change.consume()
                    val delta = -dragAmount / size.height
                    if (change.position.x < size.width / 2) {
                        brightness = (brightness + delta).coerceIn(0.05f, 1.0f)
                        activity.window.attributes = activity.window.attributes.apply { screenBrightness = brightness }
                        activeGestureText = "Brightness: ${(brightness * 100).toInt()}%"
                    } else {
                        val volDelta = (delta * maxVolume).toInt()
                        if (volDelta != 0) {
                            volumeLevel = (volumeLevel + volDelta).coerceIn(0, maxVolume)
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volumeLevel, 0)
                        }
                        activeGestureText = "Volume: ${((volumeLevel.toFloat() / maxVolume) * 100).toInt()}%"
                    }
                }
            )
        }
    ) {
        AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = exoPlayer } }, modifier = Modifier.fillMaxSize())

        Row(modifier = Modifier.align(Alignment.TopEnd).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = {
                speedIndex = (speedIndex + 1) % speeds.size
                exoPlayer.setPlaybackSpeed(speeds[speedIndex])
            }) { Text("${speeds[speedIndex]}x") }

            FilledTonalButton(onClick = { timerIndex = (timerIndex + 1) % timerOptions.size }) {
                val t = timerOptions[timerIndex]
                Text(if (t == 0) "Timer: Off" else "Timer: ${t}m")
            }

            IconButton(onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
                }
            }) { Icon(Icons.Default.PictureInPictureAlt, contentDescription = "Pop-up", tint = Color.White) }
        }

        activeGestureText?.let { label ->
            Surface(color = Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(16.dp), modifier = Modifier.align(Alignment.Center)) {
                Text(label, color = Color.White, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
            }
        }
    }
}

@Composable
fun SnifferBrowserScreen(onVideoDetected: (String) -> Unit) {
    val clipboardManager = LocalClipboardManager.current
    var urlInput by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val restrictedDomains = listOf("youtube.com", "youtu.be", "googlevideo.com")
    val videoExtensions = listOf(".mp4", ".m3u8", ".webm", ".mkv", ".mov")
    val bookmarks = listOf(
        "Vimeo" to "https://vimeo.com",
        "Dailymotion" to "https://www.dailymotion.com",
        "Pexels Videos" to "https://www.pexels.com/videos/",
        "Archive.org" to "https://archive.org/details/movies"
    )

    fun navigateToInput(raw: String) {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return
        val target = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${Uri.encode(trimmed)}"
        }
        urlInput = target
        webViewRef?.loadUrl(target)
    }

    BackHandler(enabled = webViewRef?.canGoBack() == true) { webViewRef?.goBack() }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                placeholder = { Text("Paste video link or search...", maxLines = 1) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { navigateToInput(urlInput) }),
                trailingIcon = {
                    Row {
                        IconButton(onClick = {
                            clipboardManager.getText()?.text?.let { urlInput = it; navigateToInput(it) }
                        }) { Icon(Icons.Default.ContentPaste, contentDescription = "Paste") }
                        if (urlInput.isNotEmpty()) {
                            IconButton(onClick = { urlInput = "" }) { Icon(Icons.Default.Clear, contentDescription = "Clear") }
                        }
                    }
                },
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { webViewRef?.reload() }) { Icon(Icons.Default.Refresh, contentDescription = "Reload") }
        }

        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(bookmarks) { (title, link) ->
                AssistChip(onClick = { navigateToInput(link) }, label = { Text(title) })
            }
        }

        if (isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            isLoading = true; if (url != null) urlInput = url
                        }
                        override fun onPageFinished(view: WebView?, url: String?) { isLoading = false }
                        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                            val url = request?.url?.toString() ?: return super.shouldInterceptRequest(view, request)
                            val lower = url.lowercase()
                            if (restrictedDomains.any { lower.contains(it) }) return super.shouldInterceptRequest(view, request)
                            if (videoExtensions.any { lower.contains(it) }) view?.post { onVideoDetected(url) }
                            return super.shouldInterceptRequest(view, request)
                        }
                    }
                    loadUrl("https://www.google.com")
                    webViewRef = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun DownloadsTabScreen(activity: FragmentActivity, onPlayVideo: (Uri) -> Unit) {
    val workManager = remember { WorkManager.getInstance(activity) }
    val workInfos by workManager.getWorkInfosByTagLiveData("VIDEO_DOWNLOAD").observeAsState(emptyList())
    var refreshTrigger by remember { mutableIntStateOf(0) }
    var fileToDelete by remember { mutableStateOf<File?>(null) }

    val activeDownloads = workInfos.filter { it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.ENQUEUED }
    val downloadDir = activity.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
    val completedFiles = remember(workInfos, refreshTrigger) {
        downloadDir?.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
    }

    fileToDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { fileToDelete = null },
            title = { Text("Delete File?") },
            text = { Text("Permanently delete "${target.name}"?") },
            confirmButton = {
                TextButton(onClick = {
                    if (VaultManager.deleteFile(target)) {
                        refreshTrigger++
                        Toast.makeText(activity, "File deleted", Toast.LENGTH_SHORT).show()
                    }
                    fileToDelete = null
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { fileToDelete = null }) { Text("Cancel") } }
        )
    }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        if (activeDownloads.isNotEmpty()) {
            item { Text("Downloading (${activeDownloads.size})", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(16.dp)) }
            items(activeDownloads, key = { it.id }) { info ->
                val progress = info.progress.getInt("PROGRESS", 0)
                val name = info.progress.getString("FILE_NAME") ?: "Downloading video..."
                ListItem(
                    headlineContent = { Text("$name ($progress%)", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) },
                    trailingContent = {
                        IconButton(onClick = { workManager.cancelWorkById(info.id) }) { Icon(Icons.Default.Close, contentDescription = "Cancel") }
                    }
                )
            }
        }

        item { Text("Completed", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(16.dp)) }
        items(completedFiles, key = { it.absolutePath }) { file ->
            val uri = Uri.fromFile(file)
            var expanded by remember { mutableStateOf(false) }
            ListItem(
                headlineContent = { Text(file.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(StreamInspector.formatBytes(file.length())) },
                leadingContent = { VideoThumbnail(videoUri = uri) },
                trailingContent = {
                    Box {
                        IconButton(onClick = { expanded = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Options") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            if (!file.name.endsWith(".m4a")) {
                                DropdownMenuItem(
                                    text = { Text("Extract Audio (.m4a)") },
                                    leadingIcon = { Icon(Icons.Default.Audiotrack, contentDescription = null) },
                                    onClick = {
                                        expanded = false
                                        val audioFile = File(file.parent, "${file.nameWithoutExtension}.m4a")
                                        if (AudioExtractor.extractAudioToM4a(file, audioFile)) {
                                            refreshTrigger++
                                            Toast.makeText(activity, "Saved ${audioFile.name}", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(activity, "No audio track found", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Move to Vault") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                onClick = {
                                    expanded = false
                                    if (VaultManager.moveDownloadedFileToVault(activity, file)) {
                                        refreshTrigger++
                                        Toast.makeText(activity, "Moved to Vault", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                onClick = { expanded = false; fileToDelete = file }
                            )
                        }
                    }
                },
                modifier = Modifier.clickable { onPlayVideo(uri) }
            )
        }
    }
}

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    var notificationsEnabled by remember { mutableStateOf(AppSettings.areNotificationsEnabled(context)) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 16.dp))
        ListItem(
            headlineContent = { Text("Download Notifications") },
            supportingContent = { Text("Show live progress bar in system notification shade") },
            trailingContent = {
                Switch(checked = notificationsEnabled, onCheckedChange = {
                    notificationsEnabled = it
                    AppSettings.setNotificationsEnabled(context, it)
                })
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(activity: FragmentActivity) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()

    var activeVideoUri by remember { mutableStateOf<Uri?>(null) }
    var detectedVideoUrl by remember { mutableStateOf<String?>(null) }
    var isVaultUnlocked by remember { mutableStateOf(false) }

    var showQualitySheet by remember { mutableStateOf(false) }
    var isInspecting by remember { mutableStateOf(false) }
    var qualityOptions by remember { mutableStateOf<List<VideoQualityOption>>(emptyList()) }

    if (activeVideoUri != null) {
        BackHandler { activeVideoUri = null }
        GestureVideoPlayer(videoUri = activeVideoUri!!, activity = activity)
        return
    }

    if (showQualitySheet) {
        ModalBottomSheet(onDismissRequest = { showQualitySheet = false }) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
                Text("Select Video Quality", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))

                if (isInspecting) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 24.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text("Checking resolutions, file size & duration...")
                    }
                } else {
                    qualityOptions.forEach { option ->
                        ListItem(
                            headlineContent = { Text(option.label, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Size: ${option.sizeText}  •  Duration: ${option.durationText}") },
                            leadingContent = { Icon(Icons.Default.HighQuality, contentDescription = null) },
                            trailingContent = {
                                FilledTonalButton(onClick = {
                                    val cleanLabel = option.label.replace(" ", "_")
                                    startVideoDownload(activity, option.url, "video_${cleanLabel}_${System.currentTimeMillis()}.mp4")
                                    showQualitySheet = false
                                    detectedVideoUrl = null
                                    Toast.makeText(activity, "Downloading ${option.label}...", Toast.LENGTH_SHORT).show()
                                }) { Text("Download") }
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
                val items = listOf(
                    Triple("videos", "Videos", Icons.Default.VideoLibrary),
                    Triple("browser", "Browser", Icons.Default.Public),
                    Triple("downloads", "Downloads", Icons.Default.Download),
                    Triple("vault", "Vault", Icons.Default.Lock),
                    Triple("settings", "Settings", Icons.Default.Settings)
                )
                items.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = {
                            if (route == "vault" && !isVaultUnlocked) {
                                VaultManager.authenticateUser(activity) {
                                    isVaultUnlocked = true
                                    navController.navigate("vault")
                                }
                            } else {
                                navController.navigate(route) {
                                    popUpTo(navController.graph.startDestinationId)
                                    launchSingleTop = true
                                }
                            }
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        },
        floatingActionButton = {
            detectedVideoUrl?.let { url ->
                ExtendedFloatingActionButton(
                    onClick = {
                        showQualitySheet = true
                        isInspecting = true
                        scope.launch {
                            qualityOptions = StreamInspector.inspectStream(url)
                            isInspecting = false
                        }
                    },
                    icon = { Icon(Icons.Default.Download, contentDescription = null) },
                    text = { Text("Choose Quality") }
                )
            }
        }
    ) { padding ->
        NavHost(navController = navController, startDestination = "videos", modifier = Modifier.padding(padding)) {
            composable("videos") {
                val videos = remember { VaultManager.getLocalVideos(activity) }
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(videos) { uri ->
                        ListItem(
                            headlineContent = { Text(uri.lastPathSegment ?: "Local Video") },
                            leadingContent = { VideoThumbnail(videoUri = uri) },
                            modifier = Modifier.clickable { activeVideoUri = uri }
                        )
                    }
                }
            }
            composable("browser") { SnifferBrowserScreen(onVideoDetected = { detectedVideoUrl = it }) }
            composable("downloads") { DownloadsTabScreen(activity = activity, onPlayVideo = { activeVideoUri = it }) }
            composable("vault") {
                val vaultDir = File(activity.filesDir, "private_vault")
                var refreshVault by remember { mutableIntStateOf(0) }
                val hiddenFiles = remember(refreshVault) { vaultDir.listFiles()?.toList() ?: emptyList() }
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(hiddenFiles, key = { it.absolutePath }) { file ->
                        val uri = Uri.fromFile(file)
                        ListItem(
                            headlineContent = { Text(file.name) },
                            leadingContent = { VideoThumbnail(videoUri = uri) },
                            trailingContent = {
                                IconButton(onClick = {
                                    if (VaultManager.restoreFromVault(activity, file)) {
                                        refreshVault++
                                        Toast.makeText(activity, "Restored to Downloads", Toast.LENGTH_SHORT).show()
                                    }
                                }) { Icon(Icons.Default.LockOpen, contentDescription = "Unhide") }
                            },
                            modifier = Modifier.clickable { activeVideoUri = uri }
                        )
                    }
                }
            }
            composable("settings") { SettingsScreen() }
        }
    }
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.READ_MEDIA_VIDEO)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }.toTypedArray()
        requestPermissions(permissions, 100)

        setContent {
            MaterialTheme {
                MainAppScreen(activity = this)
            }
        }
    }
}
